const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000; // หรือพอร์ตที่คุณต้องการ

// เปิดการใช้งาน JSON สำหรับการแลกเปลี่ยนข้อมูล
app.use(bodyParser.json());
// เปิดการใช้งาน URL encoded data สำหรับการแลกเปลี่ยนข้อมูล
app.use(bodyParser.urlencoded({ extended: true }));

// กำหนดการเชื่อมต่อฐานข้อมูล MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // ชื่อผู้ใช้ฐานข้อมูล MySQL
    password: '', // รหัสผ่านฐานข้อมูล MySQL
    database: 'register' // ชื่อฐานข้อมูล MySQL
});

// เชื่อมต่อกับ MySQL
connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL: ' + err.stack);
        return;
    }
    console.log('Connected to MySQL as id ' + connection.threadId);
});

// เพิ่มเส้นทางสำหรับการลงทะเบียนผู้ใช้
app.post('/register', (req, res) => {
    const { name, studentID, email, password, confirmPassword } = req.body;

    // ตรวจสอบว่ารหัสผ่านตรงกันหรือไม่
    if (password !== confirmPassword) {
        return res.status(400).send('Password and confirm password do not match');
    }

    // เตรียมคำสั่ง SQL สำหรับเพิ่มข้อมูลผู้ใช้
    const sql = 'INSERT INTO users (name, studentID, email, password) VALUES (?, ?, ?, ?)';
    const values = [name, studentID, email, password];

    // ทำการเพิ่มข้อมูลผู้ใช้ลงในฐานข้อมูล
    connection.query(sql, values, (err, result) => {
        if (err) {
            console.error('Error registering user: ' + err.stack);
            return res.status(500).send('Internal Server Error');
        }
        console.log('User registered successfully');
        res.status(200).send('Registration successful');
    });
});

app.get('/', function(req, res){
    // req is requsest from client to server  สีดำ,สีฟ้าใช้อยู่
    // res is reponse from server to client สีเท่า,สีน้่ำเงินไม่ใช้
     res.sendFile(path.join(__dirname, 'view/login.html'));//เปลี่ยนข้อความต้องรีสาร์ตเซิฟเวอร์ใหม่ 
});

// เริ่มต้นเซิร์ฟเวอร์
app.listen(PORT, () => {
    console.log('Server is running at port ' + PORT);
});
module.exports = con;
