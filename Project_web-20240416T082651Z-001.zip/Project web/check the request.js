const express = require('express');
const path = require('path');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

app.use('/public', express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use("/view", express.static(path.join(__dirname, "view")));

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'check'
});

const borrowData = [
    {
        number: 1,
        name_book: 'Harry PotterI',
        approval_request_Date: '2/3/2024',
        returned_date: '8/3/2024',
        approval_date: '9/3/2024',
        status: 'Approve'
    },
    // Add more sample data as needed
];

app.get('/check', function(req, res) {
    res.sendFile(path.join(__dirname, "view/Check the request user copy.html"));
});

app.post('/submit-form', (req, res) => {
    res.send('Form submitted successfully');
});

app.get('/fetch-data', (req, res) => {
    res.send(borrowData); // Sending sample data for demonstration
});

app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});
