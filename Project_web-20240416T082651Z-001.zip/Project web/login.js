const express = require('express');
const path = require('path');
const bcrypt = require('bcrypt');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000; // หรือพอร์ตที่คุณต้องการ

// เซ็ตอัพ static folder
app.use('/public', express.static(path.join(__dirname, 'public')));
// เปิดการใช้งาน JSON สำหรับการแลกเปลี่ยนข้อมูล
app.use(bodyParser.json());
// เปิดการใช้งาน URL encoded data สำหรับการแลกเปลี่ยนข้อมูล
app.use(bodyParser.urlencoded({ extended: true }));
app.use("/view", express.static(path.join(__dirname, "view")));

// กำหนดค่า saltRounds
const saltRounds = 10;

// กำหนดการเชื่อมต่อฐานข้อมูล MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // ชื่อผู้ใช้ฐานข้อมูล MySQL
    password: '', // รหัสผ่านฐานข้อมูล MySQL
    database: 'login'// ชื่อฐานข้อมูล MySQL
});

connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('MySQL Successfully Connected');
});

app.get('/Signin',function(req,res){
    res.sendFile(path.join(__dirname, "view/Login.html"));
})

// เพิ่มเส้นทางสำหรับการเข้าสู่ระบบ
// http://localhost:3000/Signin
app.post('/Signin', function (req, res) {
    const username = req.body.username;
    const password = req.body.password;

    const sql = "SELECT id, password, role FROM user WHERE username = ?";
    connection.query(sql, [username], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Database server error");
        }
        if (results.length !== 1) {
            return res.status(401).send("Wrong username");
        }
        bcrypt.compare(password, results[0].password, (err, same) => {
            if (err) {
                return res.status(500).send("Authentication server error");
            }
            if (same) {
                // Redirect based on user's role
                let redirectTo;
                switch (results[0].role) {
                    case "user":
                        redirectTo = "/user/list";
                        break;
                    case "staff":
                        redirectTo = "/staff/list1";
                        break;
                    case "lander":
                        redirectTo = "/lander/list2";
                        break;
                    default:
                        redirectTo = "/";
                        break;
                }
                return res.status(200).json({ redirectTo });
            } else {
                return res.status(401).send("Wrong password");
            }
        });
    });
});

app.get('/user/list',function(req,res){
    res.sendFile(path.join(__dirname, "/view/Lists_of_books(borrower) .html"));
})
app.get('/staff/list1',function(req,res){
    res.sendFile(path.join(__dirname, "/view/List of books(Staff)1 copy 3.html"));
})
app.get('/lander/list2',function(req,res){
    res.sendFile(path.join(__dirname, "/view/Lists_of_books(lander)  .html"));
})
// จัดการข้อผิดพลาดทั่วไป
app.use(function (err, req, res, next) {
    console.error(err.stack);
    res.status(500).send('Internal Server Error');
});
app.get('/Register',function(req,res){
    res.sendFile(path.join(__dirname, "view/Login.html"));
})

//localhost:3000/Register
app.post("/Register", function (req, res) {
    const name = req.body.name;
    const username = req.body.username;
    const student_id = req.body.student_id;
    const email = req.body.email;
    const password = req.body.password;

    // ตรวจสอบว่าชื่อผู้ใช้งานหรืออีเมลซ้ำกันหรือไม่
    const checkDuplicateQuery = "SELECT * FROM user WHERE username = ? OR email = ? OR student_id = ?";
    connection.query(checkDuplicateQuery, [username, email, student_id], function (err, results) {
        if (err) {
            console.error(err);
            return res.status(500).send("Database server error");
        }
        if (results.length > 0) {
            // ถ้ามีชื่อผู้ใช้งานหรืออีเมลที่ซ้ำกันอยู่แล้ว
            return res.status(400).send("Username or email or studentid already exists");
        }

        // หากไม่มีชื่อผู้ใช้งานหรืออีเมลซ้ำกัน
        // ให้ทำการเพิ่มข้อมูลผู้ใช้งานเข้าสู่ฐานข้อมูล
        bcrypt.hash(password, saltRounds, function (err, hash) {
            if (err) {
                return res.status(500).send("Hashing error");
            }
            var sql = "INSERT INTO user (name, username, student_id, email, password, role) VALUES (?, ?, ?, ?, ?, ?)";
            const role = "user";
            connection.query(sql, [name, username, student_id, email, hash, role], function (err, result) {
                if (err) {
                    console.error(err);
                    return res.status(500).send("Database server error");
                }
                return res.status(200).send("Registration successful");
            });
        });
    });
});




app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "view/Login.html"));
});



// เริ่มต้นเซิร์ฟเวอร์
app.listen(PORT, function () {
    console.log('Server is running at port ' + PORT);
});
